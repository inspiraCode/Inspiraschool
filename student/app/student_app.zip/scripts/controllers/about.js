'use strict';

/**
 * @ngdoc function
 * @name studentApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the studentApp
 */
angular.module('studentApp')
  .controller('AboutCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
