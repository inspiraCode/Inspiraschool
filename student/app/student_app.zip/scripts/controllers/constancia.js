'use strict';

/**
 * @ngdoc function
 * @name studentApp.controller:ConstanciaCtrl
 * @description
 * # ConstanciaCtrl
 * Controller of the studentApp
 */
angular.module('studentApp')
  .controller('ConstanciaCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
